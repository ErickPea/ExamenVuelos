package com.sena.tiendabackend.IService;

import com.sena.tiendabackend.Entity.DescripcionVentas;

public interface IDescripcionVentasService extends IBaseService<DescripcionVentas>{

    
}
