package com.sena.tiendabackend.IService;

import com.sena.tiendabackend.Entity.Ventas;

public interface IVentasService extends IBaseService<Ventas>{

    
}
