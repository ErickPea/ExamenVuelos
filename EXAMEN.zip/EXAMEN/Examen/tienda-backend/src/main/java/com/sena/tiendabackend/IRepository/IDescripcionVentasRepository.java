package com.sena.tiendabackend.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.tiendabackend.Entity.DescripcionVentas;

@Repository
public interface IDescripcionVentasRepository extends IBaseRepository<DescripcionVentas, Long>{


    
}
