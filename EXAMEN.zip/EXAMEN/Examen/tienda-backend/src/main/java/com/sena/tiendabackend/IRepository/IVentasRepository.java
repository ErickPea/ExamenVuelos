package com.sena.tiendabackend.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.tiendabackend.Entity.Ventas;

@Repository
public interface IVentasRepository extends IBaseRepository<Ventas, Long>{


    
}
