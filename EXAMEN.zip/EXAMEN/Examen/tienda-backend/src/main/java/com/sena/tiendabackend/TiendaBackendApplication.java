package com.sena.tiendabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaBackendApplication.class, args);
	}

}
