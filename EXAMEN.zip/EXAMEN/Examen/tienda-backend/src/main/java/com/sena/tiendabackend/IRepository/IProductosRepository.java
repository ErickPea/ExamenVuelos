package com.sena.tiendabackend.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.tiendabackend.Entity.Productos;

@Repository
public interface IProductosRepository  extends IBaseRepository<Productos, Long>{


}
