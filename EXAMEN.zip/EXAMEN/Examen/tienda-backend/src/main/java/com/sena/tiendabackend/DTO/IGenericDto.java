package com.sena.tiendabackend.DTO;

public interface IGenericDto {

    Long getId();
	Boolean getState();
    
}
