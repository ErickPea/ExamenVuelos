package com.sena.tiendabackend.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.tiendabackend.Entity.Clientes;

@Repository
public interface IClientesRepository extends IBaseRepository<Clientes, Long>{


    
}
