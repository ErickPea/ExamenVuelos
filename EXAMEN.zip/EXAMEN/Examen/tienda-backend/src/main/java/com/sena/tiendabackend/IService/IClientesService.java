package com.sena.tiendabackend.IService;

import com.sena.tiendabackend.Entity.Clientes;

public interface IClientesService extends IBaseService<Clientes>{

    
}
