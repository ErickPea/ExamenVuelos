package com.sena.tiendabackend.IService;

import com.sena.tiendabackend.Entity.Productos;

public interface IProductosService extends IBaseService<Productos>{

    
}
