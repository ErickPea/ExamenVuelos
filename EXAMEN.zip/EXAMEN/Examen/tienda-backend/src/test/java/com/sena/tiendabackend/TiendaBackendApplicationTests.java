package com.sena.tiendabackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
