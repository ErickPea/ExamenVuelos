package com.examen.vuelos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VuelosApplicationTests {

	@Test
	void contextLoads() {
	}

}
