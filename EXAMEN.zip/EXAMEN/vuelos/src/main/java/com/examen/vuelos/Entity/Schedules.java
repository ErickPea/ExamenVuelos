package com.examen.vuelos.Entity;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Table(name="schedules ")
@Entity
public class Schedules extends ABaseEntity {
	@Id
	@Column(name = "Date", length = 50, nullable = false)
    private LocalDate Date; //se coloca LocalDate  Para representar solo una fecha (sin hora)
	
	@Column(name = "Time", length = 50, nullable = false)
    private LocalTime Time; //se coloca  LocalTime Para representar solo una hora (sin fecha
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Aircraft_id", nullable = true)
    private Aircraft Aircraft;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Routes_id", nullable = true)
    private Routes Routes;
	
	@Column(name = "EconomyPrice", length = 50, nullable = false)
    private String EconomyPrice;
	
	@Column(name = "Confirmed", length = 50, nullable = false)
    private String Confirmed;
	
	@Column(name = "FlightNumber", length = 50, nullable = false)
    private String FlightNumber;

	public LocalDate getDate() {
		return Date;
	}

	public void setDate(LocalDate date) {
		Date = date;
	}

	public LocalTime getTime() {
		return Time;
	}

	public void setTime(LocalTime time) {
		Time = time;
	}

	public Aircraft getAircraft() {
		return Aircraft;
	}

	public void setAircraft(Aircraft aircraft) {
		Aircraft = aircraft;
	}

	public Routes getRoutes() {
		return Routes;
	}

	public void setRoutes(Routes routes) {
		Routes = routes;
	}

	public String getEconomyPrice() {
		return EconomyPrice;
	}

	public void setEconomyPrice(String economyPrice) {
		EconomyPrice = economyPrice;
	}

	public String getConfirmed() {
		return Confirmed;
	}

	public void setConfirmed(String confirmed) {
		Confirmed = confirmed;
	}

	public String getFlightNumber() {
		return FlightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		FlightNumber = flightNumber;
	}
	
	
}
