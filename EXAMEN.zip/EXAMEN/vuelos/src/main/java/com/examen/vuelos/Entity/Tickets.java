package com.examen.vuelos.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Table(name="Tickets ")
@Entity
public class Tickets extends ABaseEntity {
	
	@Id
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Users_id", nullable = true)
    private Users Users;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Schedule_id", nullable = true)
    private Schedules Schedule;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Cabin_Type_id", nullable = true)
    private Cabin_Type Cabin_Type;
	
	@Column(name = "FirstName", length = 50, nullable = false)
    private String FirstName;
	
	@Column(name = "LastName", length = 50, nullable = false)
    private String LastName;
	
	@Column(name = "Email", length = 50, nullable = false)
    private String Email;
	
	@Column(name = "Phoned", length = 50, nullable = false)
    private String Phoned;
	
	@Column(name = "PassportNumber", length = 50, nullable = false)
    private String PassportNumber;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Passport_Country_id", nullable = true)
    private Country Passport_Country;
	
	@Column(name = "PassportPhoto", length = 50, nullable = false)
    private String PassportPhoto;
	
	@Column(name = "BookingReference", length = 50, nullable = false)
    private String BookingReference;
	
	@Column(name = "Confirmed", length = 50, nullable = false)
    private String Confirmed;
	
	
	
	
	public Users getUser() {
		return Users;
	}
	public void setUser(Users user) {
		Users = user;
	}
	public Schedules getSchedule() {
		return Schedule;
	}
	public void setSchedule(Schedules schedule) {
		Schedule = schedule;
	}
	
	
	public Cabin_Type getCabin_Type() {
		return Cabin_Type;
	}
	public void setCabin_Type(Cabin_Type cabin_Type) {
		Cabin_Type = cabin_Type;
	}
	
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	
	
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	
	
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	
	public String getPhoned() {
		return Phoned;
	}
	public void setPhoned(String phoned) {
		Phoned = phoned;
	}
	
	
	public String getPassportNumber() {
		return PassportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		PassportNumber = passportNumber;
	}
	
	
	public Country getPassport_Country() {
		return Passport_Country;
	}
	public void setPassport_Country(Country passport_Country) {
		Passport_Country = passport_Country;
	}
	
	
	public String getPassportPhoto() {
		return PassportPhoto;
	}
	public void setPassportPhoto(String passportPhoto) {
		PassportPhoto = passportPhoto;
	}
	
	
	public String getBookingReference() {
		return BookingReference;
	}
	public void setBookingReference(String bookingReference) {
		BookingReference = bookingReference;
	}
	
	
	public String getConfirmed() {
		return Confirmed;
	}
	public void setConfirmed(String confirmed) {
		Confirmed = confirmed;
	}
	

}
