package com.examen.vuelos.IRepository;

import org.springframework.stereotype.Repository;

import com.examen.vuelos.Entity.Schedules;
@Repository
public interface SchedulesIRepository extends IBaseRepository<Schedules, Long>{

}
