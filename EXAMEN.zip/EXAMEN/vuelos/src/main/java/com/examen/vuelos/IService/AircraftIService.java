package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Aircraft;
public interface AircraftIService extends IBaseService<Aircraft>{

}
