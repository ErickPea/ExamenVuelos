package com.examen.vuelos.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Table(name="Office")
@Entity
public class Office extends ABaseEntity{
	@Id
	 private Long id;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "country_id", nullable = true)
    private Country country;
	
	@Column(name = "Title", length = 50, nullable = false)
    private String Title;
	
	@Column(name = "Phone", length = 50, nullable = false)
    private String Phone;
	
	@Column(name = "Contact", length = 50, nullable = false)
    private String Contact;
	
	
	
	
	
	
	
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	
	
	
}
