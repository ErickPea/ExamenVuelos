package com.examen.vuelos.IRepository;

import org.springframework.stereotype.Repository;
import com.examen.vuelos.Entity.Aircraft;

@Repository
public interface AircraftsIRepository extends IBaseRepository<Aircraft, Long>{

}
