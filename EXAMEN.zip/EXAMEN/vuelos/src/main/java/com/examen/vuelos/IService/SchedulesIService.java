package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Schedules;
public interface SchedulesIService extends IBaseService<Schedules> {

}
