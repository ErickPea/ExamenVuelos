package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Role;
public interface RoleIService extends IBaseService<Role>{

}
