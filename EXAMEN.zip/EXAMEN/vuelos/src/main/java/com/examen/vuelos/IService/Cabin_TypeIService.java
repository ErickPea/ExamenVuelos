package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Cabin_Type;
public interface Cabin_TypeIService extends IBaseService<Cabin_Type>{

}
