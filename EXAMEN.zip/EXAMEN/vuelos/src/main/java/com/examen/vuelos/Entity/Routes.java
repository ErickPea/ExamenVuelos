package com.examen.vuelos.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Table(name="Routes")
@Entity
public class Routes extends ABaseEntity{
@Id
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Arrival_Aiport_id", nullable = true)
    private Airports Arrival_Aiport;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "Departure_Aiport_id", nullable = true)
    private Airports Departure_Aiport_id;
	
	@Column(name = "Distance", length = 50, nullable = false)
    private String Distance;
	
	@Column(name = "Flight_Time", length = 50, nullable = false)
    private String Flight_Time;

	public Airports getArrival_Aiport() {
		return Arrival_Aiport;
	}

	public void setArrival_Aiport(Airports arrival_Aiport) {
		Arrival_Aiport = arrival_Aiport;
	}

	public Airports getDeparture_Aiport_id() {
		return Departure_Aiport_id;
	}

	public void setDeparture_Aiport_id(Airports departure_Aiport_id) {
		Departure_Aiport_id = departure_Aiport_id;
	}

	public String getDistance() {
		return Distance;
	}

	public void setDistance(String distance) {
		Distance = distance;
	}

	public String getFlight_Time() {
		return Flight_Time;
	}

	public void setFlight_Time(String flight_Time) {
		Flight_Time = flight_Time;
	}
	
	
}
