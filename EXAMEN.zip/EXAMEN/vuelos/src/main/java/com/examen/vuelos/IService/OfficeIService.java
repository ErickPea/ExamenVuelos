package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Office;
public interface OfficeIService extends IBaseService<Office>{

}
