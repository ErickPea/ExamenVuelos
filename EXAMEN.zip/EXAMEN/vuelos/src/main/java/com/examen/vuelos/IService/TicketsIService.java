package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Tickets;
public interface TicketsIService extends IBaseService<Tickets>{

}
