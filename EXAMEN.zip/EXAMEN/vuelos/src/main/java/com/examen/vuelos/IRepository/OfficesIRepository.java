package com.examen.vuelos.IRepository;

import org.springframework.stereotype.Repository;

import com.examen.vuelos.Entity.Office;
@Repository
public interface OfficesIRepository extends IBaseRepository<Office, Long>{

	
}
