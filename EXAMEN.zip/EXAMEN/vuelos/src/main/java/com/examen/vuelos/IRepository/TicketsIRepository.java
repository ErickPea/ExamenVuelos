package com.examen.vuelos.IRepository;
import org.springframework.stereotype.Repository;

import com.examen.vuelos.Entity.Tickets;
@Repository
public interface TicketsIRepository extends IBaseRepository<Tickets, Long>{

}
