package com.examen.vuelos.IRepository;

import org.springframework.stereotype.Repository;
import com.examen.vuelos.Entity.Role;
@Repository
public interface RolesIRepository extends IBaseRepository<Role, Long>{

}
