package com.examen.vuelos.IService;

import com.examen.vuelos.Entity.Users;

public interface UsersIService extends IBaseService<Users>{

}
