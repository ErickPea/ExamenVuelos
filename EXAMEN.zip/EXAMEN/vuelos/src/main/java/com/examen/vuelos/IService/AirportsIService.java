package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Airports;
public interface AirportsIService extends IBaseService<Airports>{

}
