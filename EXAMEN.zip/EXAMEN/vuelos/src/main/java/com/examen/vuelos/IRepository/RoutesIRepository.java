package com.examen.vuelos.IRepository;

import org.springframework.stereotype.Repository;
import com.examen.vuelos.Entity.Routes;

@Repository
public interface RoutesIRepository extends IBaseRepository<Routes, Long>{

}
