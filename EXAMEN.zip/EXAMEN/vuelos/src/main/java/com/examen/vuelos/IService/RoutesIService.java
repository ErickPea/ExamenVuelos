package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Routes;
public interface RoutesIService extends IBaseService<Routes> {

}
