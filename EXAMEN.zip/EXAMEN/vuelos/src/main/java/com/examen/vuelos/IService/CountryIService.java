package com.examen.vuelos.IService;
import com.examen.vuelos.Entity.Country;
public interface CountryIService extends IBaseService<Country>{

}
