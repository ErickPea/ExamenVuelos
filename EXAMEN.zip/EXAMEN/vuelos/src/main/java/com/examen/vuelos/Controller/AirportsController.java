package com.examen.vuelos.Controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.examen.vuelos.Entity.Airports;
import com.examen.vuelos.IService.AirportsIService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/Airports")
public class AirportsController extends ABaseController<Airports, AirportsIService>{

	public AirportsController(AirportsIService service) {
		super(service, "Airports");
		// TODO Auto-generated constructor stub
	}

}
